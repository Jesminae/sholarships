# SCHOLARSHIP PORTAL 🎯


## Basic Details
### Team Name: XXX


### Team Members
- Member 1: Adila Shaharban - GCEK
- Member 2: JESMINA E - GCEK
- Member 3: ABDA SAJJAD - GCEK

### Hosted Project Link


### Project Description
Helps to connect college authorities with the students.provides a portal where the authorities can upload the scholarship details and all the criterias  of the scholarship . Students can access the same through their login page to get notified about all the available ones on time and can  also check whether they are eligible for the scholarship or not and to upload the necessary documents that are required which helps to minimize the office rush and the troubles regarding document submission.

### The Problem statement
Students are not always able to apply for the schlarships  due to lack of awarness about the details and also document submission beomes a hazardous task since they have to visit the offices multiple times for  a single scholarship itself.

### The Solution
we make it easier for the students to have all the details in their fingertip by providing the necessities in a single page and can also uload the files via the portal.

## Technical Details
### Technologies/Components Used
For Software:
- html,css,javascript,python flask
- flask,flask-cors

### Implementation
For Software:
# Installation
pip install flask
pip install flaskcors

# Run
python app.py

### Project Documentation
For Software:

# Screenshots (Add at least 3)
![Screenshot1](Add screenshot 1 here with proper name)
*Add caption explaining what this shows*

![Screenshot2](Add screenshot 2 here with proper name)
*Add caption explaining what this shows*

![Screenshot3](Add screenshot 3 here with proper name)
*Add caption explaining what this shows*

# Diagrams
![Workflow](Add your workflow/architecture diagram here)
*Add caption explaining your workflow*



## Team Contributions
- Adila Shaharban -Back end ,Front end,
- Jesmina E: Front end
- ABDA:  idea,documentation

---
Made with ❤️ at TinkerHub
